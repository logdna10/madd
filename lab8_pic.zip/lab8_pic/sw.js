var mycache = "mycache";
var assests = [
"/",
"/index.html",
"/img/image1.jpg",
"/img/image2.jpg",
"/img/image3.jpeg",
"/img/image4.jpg",
"/js/start.js",
"/sw.js",
"/manifest.json",
];

self.addEventListener('install', event => {
console.log('inside the install', event);
caches.open(mycache)
.then(cache => {
cache.addAll(assests);
});
});

self.addEventListener('activate', event => {
console.log('inside the activate', event);
});

self.addEventListener('fetch', async (event) => {
event.respondWith(
caches.match(event.request)
.then(respevt => {
return respevt || fetch(event.request);
})
);
console.log('inside the fetched', event);
});