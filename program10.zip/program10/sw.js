self.addEventListener("install", (e) => {
    console.log("installed");
    caches.open("stock").then((cache)=>{
        cache.add("/");
        cache.add("./asset/img1.png");
        cache.add("./manifest.json");
        cache.add("./index.html");
        cache.add("./data.json");
        cache.add("./index.json");
        cache.add("./sw.js");

    })
})
self.addEventListener("activate", (e) => {
    console.log("activated");
})
self.addEventListener("fetch", (e) => {
    console.log("fetched");
    e.respondWith(
        caches.match(e.request)
        .then((res)=>{
            return res||fetch(e.request);
        })
        .catch((err)=>{
            console.log(err);
        })
    );
})