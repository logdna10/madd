package com.example.lab4;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView text;
    Button click;
    ProgressBar loading;
    private int progressstatus=0;
    private Handler handler =new Handler();
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text=findViewById(R.id.textview);
        click=findViewById(R.id.click);
        loading=findViewById(R.id.loading);
        click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }

            private void showDialog() {
                AlertDialog.Builder builder= new AlertDialog.Builder(MainActivity.this);
                builder.setMessage("Are you sure you want to continue");
                builder.setTitle("Alert");
                builder.setIcon(R.mipmap.ic_launcher_round);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        startDownload();
                        dialogInterface.cancel();
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(MainActivity.this,"Selected NO",Toast.LENGTH_LONG).show();

                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();


            }

            private void startDownload() {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        while (progressstatus <= 100) {
                            progressstatus = progressstatus + 1;
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    loading.setProgress(progressstatus);
                                    text.setText(progressstatus+"/"+loading.getMax()+"%");
                                    while ( progressstatus == 100 ){
                                        comalert();
                                    }


                                }
                            });
                            try {
                                Thread.sleep(10);
                            }
                            catch (InterruptedException e){
                                e.getStackTrace();
                            }
                        }
                    }

                    private void comalert() {
                        AlertDialog.Builder builderr= new AlertDialog.Builder(MainActivity.this);
                        builderr.setMessage("Completed");
                        builderr.setTitle("Success");
                        builderr.setIcon(R.mipmap.ic_launcher);
                        builderr.show();
                    }
                }).start();

            }
        });

    }
}